import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voipswitch',
  templateUrl: './voipswitch.component.html',
  styleUrls: ['./voipswitch.component.css']
})
export class VoipswitchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
