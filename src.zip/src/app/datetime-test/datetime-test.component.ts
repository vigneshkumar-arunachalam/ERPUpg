import { Component, OnInit } from '@angular/core';





@Component({
  selector: 'app-datetime-test',
  templateUrl: './datetime-test.component.html',
  styleUrls: ['./datetime-test.component.css']
})
export class DatetimeTestComponent implements OnInit {
 
  constructor() { }

  ngOnInit(): void {
   
  }
 

}
